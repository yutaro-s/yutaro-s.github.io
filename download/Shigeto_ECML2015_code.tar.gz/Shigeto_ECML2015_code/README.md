# Usage
To see a working demo, please run demo/demo_synthetic.jl

# Credit
If you use this code in scientific work, please cite:

```
#!bibtex
@incollection{
year={2015},
isbn={978-3-319-23527-1},
booktitle={Machine Learning and Knowledge Discovery in Databases},
volume={9284},
series={Lecture Notes in Computer Science},
editor={Appice, Annalisa and Rodrigues, Pedro Pereira and Santos Costa, Vítor and Soares, Carlos and Gama, João and Jorge, Alípio},
doi={10.1007/978-3-319-23528-8_9},
title={Ridge Regression, Hubness, and Zero-Shot Learning},
url={http://dx.doi.org/10.1007/978-3-319-23528-8_9},
publisher={Springer International Publishing},
author={Shigeto, Yutaro and Suzuki, Ikumi and Hara, Kazuo and Shimbo, Masashi and Matsumoto, Yuji},
pages={135-151},
}
```
